"""
Q-HEART starter experiment
Synthetic binary classification + classical baseline + simple statevector VQC
+ transpilation metrics for two illustrative coupling maps.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from sklearn.datasets import make_classification
from sklearn.metrics import accuracy_score, f1_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import LogisticRegression

from qiskit import QuantumCircuit, transpile
from qiskit.circuit import ParameterVector
from qiskit.quantum_info import Statevector, SparsePauliOp
from qiskit.transpiler import CouplingMap

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
PROCESSORS = ROOT / "processors"
RESULTS.mkdir(exist_ok=True)

SEED = 42
N_QUBITS = 4
MAX_OPT_ITER = 35  # small budget for a beginner-friendly demonstration


def load_processor(filename: str) -> dict:
    with open(PROCESSORS / filename, "r", encoding="utf-8") as f:
        return json.load(f)


def make_logical_circuit():
    """Return a four-qubit feature-map + trainable ansatz circuit."""
    x = ParameterVector("x", N_QUBITS)
    theta = ParameterVector("theta", 2 * N_QUBITS)
    qc = QuantumCircuit(N_QUBITS)
    for q in range(N_QUBITS):
        qc.h(q)
        qc.ry(x[q], q)
    # Entangling layer
    for q in range(N_QUBITS - 1):
        qc.cx(q, q + 1)
    # Trainable rotations
    for q in range(N_QUBITS):
        qc.ry(theta[q], q)
    # A second entangling layer, reversed chain
    for q in range(N_QUBITS - 2, -1, -1):
        qc.cx(q + 1, q)
    for q in range(N_QUBITS):
        qc.ry(theta[N_QUBITS + q], q)
    return qc, x, theta


def vqc_score(features: np.ndarray, weights: np.ndarray, template, x_params, theta_params) -> float:
    """Map expectation Z on qubit 0 from [-1, 1] to a probability in [0, 1]."""
    qc = template.assign_parameters({
        **{x_params[i]: float(features[i]) for i in range(N_QUBITS)},
        **{theta_params[i]: float(weights[i]) for i in range(2 * N_QUBITS)}
    })
    state = Statevector.from_instruction(qc)
    z_expectation = float(np.real(state.expectation_value(
        SparsePauliOp.from_list(
            [("I" * (N_QUBITS - 1) + "Z", 1.0)]
        )
    )))
    # Probability of class 1, clipped to avoid log(0).
    return float(np.clip((1.0 - z_expectation) / 2.0, 1e-7, 1 - 1e-7))


def main():
    print("Q-HEART: starting experiment")
    X, y = make_classification(
        n_samples=160,
        n_features=4,
        n_informative=3,
        n_redundant=0,
        n_repeated=0,
        n_classes=2,
        random_state=SEED
    )
    data = pd.DataFrame(X, columns=[f"feature_{i+1}" for i in range(4)])
    data["label"] = y
    data.to_csv(RESULTS / "synthetic_dataset.csv", index=False)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=SEED, stratify=y
    )
    # Map inputs to [0, pi], suitable for angle encoding.
    scaler = MinMaxScaler(feature_range=(0, np.pi))
    X_train_q = scaler.fit_transform(X_train)
    X_test_q = scaler.transform(X_test)

    classical = make_pipeline(
        MinMaxScaler(),
        LogisticRegression(max_iter=1000, random_state=SEED)
    )
    classical.fit(X_train, y_train)
    classical_pred = classical.predict(X_test)
    metrics = [{
        "model": "Logistic Regression",
        "accuracy": float(accuracy_score(y_test, classical_pred)),
        "f1_score": float(f1_score(y_test, classical_pred, zero_division=0))
    }]

    logical, x_params, theta_params = make_logical_circuit()
    initial_weights = np.random.default_rng(SEED).uniform(-0.5, 0.5, 2 * N_QUBITS)

    # Small subset keeps statevector training practical for a first run.
    train_limit = min(64, len(X_train_q))
    X_fit = X_train_q[:train_limit]
    y_fit = y_train[:train_limit]

    def loss(weights):
        probabilities = np.array([
            vqc_score(row, weights, logical, x_params, theta_params)
            for row in X_fit
        ])
        return float(-np.mean(
            y_fit * np.log(probabilities) +
            (1 - y_fit) * np.log(1 - probabilities)
        ))

    print(f"Training VQC on {train_limit} training examples (max {MAX_OPT_ITER} optimizer iterations)...")
    opt = minimize(
        loss,
        initial_weights,
        method="COBYLA",
        options={"maxiter": MAX_OPT_ITER, "rhobeg": 0.25}
    )
    vqc_prob = np.array([
        vqc_score(row, opt.x, logical, x_params, theta_params)
        for row in X_test_q
    ])
    vqc_pred = (vqc_prob >= 0.5).astype(int)
    metrics.append({
        "model": "Four-qubit VQC (statevector)",
        "accuracy": float(accuracy_score(y_test, vqc_pred)),
        "f1_score": float(f1_score(y_test, vqc_pred, zero_division=0))
    })
    pd.DataFrame(metrics).to_csv(RESULTS / "classification_metrics.csv", index=False)

    # Compile the same logical circuit separately for each topology.
    # A four-logical-qubit circuit can be mapped onto these larger graphs.
    compiled_rows = []
    for filename in ("processor_A.json", "processor_B.json"):
        spec = load_processor(filename)
        cmap = CouplingMap(couplinglist=[tuple(edge) for edge in spec["edges"]])
        compiled = transpile(
            logical,
            basis_gates=["rz", "sx", "x", "cx"],
            coupling_map=cmap,
            optimization_level=1,
            seed_transpiler=SEED
        )
        ops = compiled.count_ops()
        compiled_rows.append({
            "processor": spec["name"],
            "physical_qubits_in_graph": spec["num_qubits"],
            "compiled_circuit_qubits": int(compiled.num_qubits),
            "depth": int(compiled.depth()),
            "cx_count": int(ops.get("cx", 0)),
            "swap_count": int(ops.get("swap", 0))
        })
    pd.DataFrame(compiled_rows).to_csv(RESULTS / "compilation_metrics.csv", index=False)

    report = {
        "project": "Q-HEART",
        "dataset": "synthetic binary classification; not medical data",
        "seed": SEED,
        "vqc_optimizer_success": bool(opt.success),
        "vqc_optimizer_message": str(opt.message),
        "classification_metrics": metrics,
        "compilation_metrics": compiled_rows,
        "note": "These are outputs from this run. Connectivity graphs are illustrative, not real hardware."
    }
    with open(RESULTS / "report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    print("\nClassification metrics:")
    print(pd.DataFrame(metrics).to_string(index=False))
    print("\nCompilation metrics:")
    print(pd.DataFrame(compiled_rows).to_string(index=False))
    print(f"\nSaved output files in: {RESULTS}")
    print("Reminder: synthetic-data results do not establish medical usefulness.")


if __name__ == "__main__":
    main()
