# Q-HEART
**Quantum Hardware Evaluation and Analysis of Routing Topologies**

Q-HEART is a learning/research starter project that compares how two hypothetical processor connectivity layouts affect compilation of a four-qubit variational quantum classifier (VQC). It also compares the VQC's synthetic-data classification performance with a classical logistic-regression baseline.

## Important scope
- The dataset is synthetic and is **not medical data** or a medical diagnostic tool.
- Processor A and B are illustrative connectivity graphs, not claims about real IBM hardware.
- Circuit metrics are produced by running Qiskit transpilation; do not copy illustrative values from slides or mockups.
- A better-connected graph may reduce routing overhead, but does not automatically produce better classification accuracy.

## Project files
- `main.py`: generates data, trains/evaluates logistic regression and a small statevector VQC, and reports compilation metrics.
- `processors/processor_A.json`, `processors/processor_B.json`: connectivity definitions.
- `requirements.txt`: package versions used for the starter project.
- `main.ipynb`: notebook launcher for Colab/Jupyter.
- `results/`: output CSVs and JSON report are written here after execution.

## Run in Google Colab
1. Upload `main.py` and the `processors` folder, or clone/download this repository.
2. Install packages:
   ```python
   %pip install -r requirements.txt
   ```
3. Restart the runtime if Colab asks you to.
4. Run:
   ```python
   !python main.py
   ```
5. Review the files created in `results/`.

## Run locally
```bash
python -m pip install -r requirements.txt
python main.py
```

## Research question
How do processor connectivity and transpiler routing affect the compiled resource cost of the same logical quantum-classification circuit?

## Metrics
- Classification: accuracy and F1 score for the classical baseline and VQC.
- Compilation: transpiled circuit depth, CX gate count, and SWAP gate count for each connectivity graph.

## Reproducibility
The random seeds are fixed in the code. The VQC uses a small optimization budget so it can run as a starter demonstration. Results may still vary across software/platform versions. Report only outputs from your own run.
